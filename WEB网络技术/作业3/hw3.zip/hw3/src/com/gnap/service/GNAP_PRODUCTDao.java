package com.gnap.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.gnap.dao.Basedao;
import com.gnap.entity.GNAP_CATEGORY;
import com.gnap.entity.GNAP_PRODUCT;


public class GNAP_PRODUCTDao {
	
	public static int insert(GNAP_PRODUCT p) {
		String sql = "insert into GNAP_PRODUCT values(null, ?, ?,?,?,?,?,?)";
		
		
		Object[] params = {
					p.getPRODUCT_NAME(),
					p.getPRODUCT_DESCRIPTION(),
					p.getPRODUCT_PRICE(),
					p.getPRODUCT_STOCK(),
					p.getPRODUCT_FID(),
					p.getPRODUCT_CID(),
					p.getPRODUCT_FILENAME()
					};
		
		return Basedao.exectuIUD(sql, params);
	}
	
	public static int[] totalPage(int count,int flag,int idd) {
		// 0 总记录数， 1， 页数
		int arr[] = {0, 1};
		
		Connection conn = Basedao.getconn();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		
		
		try {
				if(flag==1)//查Cid
				{
					String sql = "select count(*) from GNAP_PRODUCT where find_in_set(";
					sql=sql+idd+",PRODUCT_CID)";
				
					System.out.print(sql);
					ps = conn.prepareStatement(sql);
				
			
		
					rs = ps.executeQuery();
			 
					while(rs.next()) {
					 arr[0]= rs.getInt(1);
					 if(arr[0]%count==0){
						 arr[1] = arr[0]/count;
					 }else{
						 arr[1] = arr[0]/count+1;
					 }
			 }
				}else//查fid
				{
					String sql = "select count(*) from GNAP_PRODUCT where find_in_set(";
					sql=sql+idd+",PRODUCT_FID)";
				
					System.out.print(sql);
					ps = conn.prepareStatement(sql);
					rs = ps.executeQuery();
			 
					while(rs.next()) {
						 arr[0]= rs.getInt(1);
						 if(arr[0]%count==0){
							 arr[1] = arr[0]/count;
						 }else{
							 arr[1] = arr[0]/count+1;
						}
					}
				}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return arr;
	}
	public static ArrayList<GNAP_PRODUCT> selectAll() {
		ArrayList<GNAP_PRODUCT> list = new ArrayList<GNAP_PRODUCT>();
		//声明结果集
		ResultSet rs = null;
		//获取连接对象
		Connection conn = Basedao.getconn();
		
		PreparedStatement ps = null;
		
		
		System.out.print("1");
		try {
			String sql = "select * from GNAP_PRODUCT";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			 while(rs.next()) {
				 GNAP_PRODUCT p = new GNAP_PRODUCT(
						 	rs.getInt("PRODUCT_ID"),
						 	rs.getString("PRODUCT_NAME"),
						 	rs.getString("PRODUCT_DESCRIPTION"),
						 	rs.getInt("PRODUCT_PRICE"),
						 	rs.getInt("PRODUCT_STOCK"),
						 	rs.getInt("PRODUCT_FID"),
						 	rs.getInt("PRODUCT_CID"),
						 	rs.getString("PRODUCT_FILENAME")
						 );
				 
				 
				 list.add(p);
				 
			 }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return list;
	}
	
	
	
	public static GNAP_PRODUCT selectById(int id) {
		GNAP_PRODUCT p = null;
		//声明结果集
		ResultSet rs = null;
		//获取连接对象
		Connection conn = Basedao.getconn();
		
		PreparedStatement ps = null;
		
		
		
		try {
			String sql = "select * from GNAP_PRODUCT where PRODUCT_ID=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			 
			 while(rs.next()) {
				  p = new GNAP_PRODUCT(
						 	rs.getInt("PRODUCT_ID"),
						 	rs.getString("PRODUCT_NAME"),
						 	rs.getString("PRODUCT_DESCRIPTION"),
						 	rs.getInt("PRODUCT_PRICE"),
						 	rs.getInt("PRODUCT_STOCK"),
						 	rs.getInt("PRODUCT_FID"),
						 	rs.getInt("PRODUCT_CID"),
						 	rs.getString("PRODUCT_FILENAME")
						 );
			 }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return p;
	}
	
	public static ArrayList<GNAP_PRODUCT> selectAllByFid(int fid,int cpage,int count) {
		ArrayList<GNAP_PRODUCT> list = new ArrayList<GNAP_PRODUCT>();
		//声明结果集
		ResultSet rs = null;
		//获取连接对象
		Connection conn = Basedao.getconn();
		
		PreparedStatement ps = null;
		
		
		
		try {
			String sql = "select * from GNAP_PRODUCT where PRODUCT_FID=?  limit ?, ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, fid);
			ps.setInt(2, (cpage-1)*count);
			ps.setInt(3, count);
			rs = ps.executeQuery();
			 
			 while(rs.next()) {
				 GNAP_PRODUCT p = new GNAP_PRODUCT(
						 	rs.getInt("PRODUCT_ID"),
						 	rs.getString("PRODUCT_NAME"),
						 	rs.getString("PRODUCT_DESCRIPTION"),
						 	rs.getInt("PRODUCT_PRICE"),
						 	rs.getInt("PRODUCT_STOCK"),
						 	rs.getInt("PRODUCT_FID"),
						 	rs.getInt("PRODUCT_CID"),
						 	rs.getString("PRODUCT_FILENAME")
						 );
				 
				 
				 list.add(p);
				 
			 }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return list;
	}
	
	
	public static ArrayList<GNAP_PRODUCT> selectAllByCid(int cid,int cpage,int count) {
		ArrayList<GNAP_PRODUCT> list = new ArrayList<GNAP_PRODUCT>();
		//声明结果集
		ResultSet rs = null;
		//获取连接对象
		Connection conn = Basedao.getconn();
		
		PreparedStatement ps = null;
		
		
		
		try {
			String sql = "select * from GNAP_PRODUCT where PRODUCT_CID=?  limit ?,?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cid);
			 ps.setInt(2, (cpage-1)*count);
			 ps.setInt(3, count);
			rs = ps.executeQuery();
			 
			 while(rs.next()) {
				 GNAP_PRODUCT p = new GNAP_PRODUCT(
						 	rs.getInt("PRODUCT_ID"),
						 	rs.getString("PRODUCT_NAME"),
						 	rs.getString("PRODUCT_DESCRIPTION"),
						 	rs.getInt("PRODUCT_PRICE"),
						 	rs.getInt("PRODUCT_STOCK"),
						 	rs.getInt("PRODUCT_FID"),
						 	rs.getInt("PRODUCT_CID"),
						 	rs.getString("PRODUCT_FILENAME")
						 );
				 
				 
				 list.add(p);
				 
			 }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return list;
	}
	
	public static ArrayList<GNAP_PRODUCT> selectAllByCid(int cid) {
		ArrayList<GNAP_PRODUCT> list = new ArrayList<GNAP_PRODUCT>();
		//声明结果集
		ResultSet rs = null;
		//获取连接对象
		Connection conn = Basedao.getconn();
		
		PreparedStatement ps = null;
		
		
		
		try {
			String sql = "select * from GNAP_PRODUCT where PRODUCT_CID=?";
			System.out.print(cid);
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cid);
			rs = ps.executeQuery();
			 
			 while(rs.next()) {
				 GNAP_PRODUCT p = new GNAP_PRODUCT(
						 	rs.getInt("PRODUCT_ID"),
						 	rs.getString("PRODUCT_NAME"),
						 	rs.getString("PRODUCT_DESCRIPTION"),
						 	rs.getInt("PRODUCT_PRICE"),
						 	rs.getInt("PRODUCT_STOCK"),
						 	rs.getInt("PRODUCT_FID"),
						 	rs.getInt("PRODUCT_CID"),
						 	rs.getString("PRODUCT_FILENAME")
						 );
				 
				 
				 list.add(p);
				 
			 }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return list;
	}
	public static ArrayList<GNAP_PRODUCT> selectAllById(ArrayList<Integer> ids) {
		ArrayList<GNAP_PRODUCT> lastlylist = new ArrayList<GNAP_PRODUCT>();
		
		 GNAP_PRODUCT p = null;
		//声明结果集
		ResultSet rs = null;
		//获取连接对象
		Connection conn = Basedao.getconn();
		
		PreparedStatement ps = null;
		
		
		
		try {
		    for(int i=0; i<ids.size(); i++) {
			
				String sql = "select * from GNAP_PRODUCT where PRODUCT_ID=?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, ids.get(i));
				rs = ps.executeQuery();
				 
				 while(rs.next()) {
					 p = new GNAP_PRODUCT(
							 	rs.getInt("PRODUCT_ID"),
							 	rs.getString("PRODUCT_NAME"),
							 	rs.getString("PRODUCT_DESCRIPTION"),
							 	rs.getInt("PRODUCT_PRICE"),
							 	rs.getInt("PRODUCT_STOCK"),
							 	rs.getInt("PRODUCT_FID"),
							 	rs.getInt("PRODUCT_CID"),
							 	rs.getString("PRODUCT_FILENAME")
							 );
					 
					 
					 lastlylist.add(p);
					 
				 }
		    }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Basedao.closeall(rs, ps, conn);
		}
		
		
		
		return lastlylist;
	}
}
