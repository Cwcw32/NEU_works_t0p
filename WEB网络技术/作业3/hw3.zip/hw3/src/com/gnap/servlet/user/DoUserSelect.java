package com.gnap.servlet.user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gnap.entity.GNAP_USER;
import com.gnap.service.GNAP_USERDao;

/**
 * Servlet implementation class DoUserSelect
 */
@WebServlet("/manage/admin_douserselect")
public class DoUserSelect extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int cpage=1;//当前页面
	
		int count=10;//每页显示条数
		
		String cp=request.getParameter("cp");
		if(cp!=null)
		{
			cpage=Integer.parseInt(cp);
		}
		//接受用户搜索的关键字
		String keyword=request.getParameter("keywords");
		
		
		int arr[]=GNAP_USERDao.totalPage(count,keyword);
		
		//获取所有用户记录
		ArrayList<GNAP_USER> list=GNAP_USERDao.selectAll(cpage,count,keyword);
		//放到请求对象里
		request.setAttribute("userlist", list);
		request.setAttribute("tsum", arr[0]);
		request.setAttribute("tpage",arr[1]);
		request.setAttribute("cpage", cpage);
		//请求转
		if(keyword!=null){
			request.setAttribute("searchParams","&keywords="+keyword);
		}
		request.getRequestDispatcher("admin_user.jsp").forward(request, response);
	}

}
