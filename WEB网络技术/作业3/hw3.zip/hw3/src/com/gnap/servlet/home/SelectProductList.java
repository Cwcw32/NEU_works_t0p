package com.gnap.servlet.home;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gnap.entity.GNAP_CATEGORY;
import com.gnap.entity.GNAP_PRODUCT;
import com.gnap.service.GNAP_CATEGORYDao;
import com.gnap.service.GNAP_PRODUCTDao;
import com.gnap.service.GNAP_USERDao;

/**
 * Servlet implementation class SelectProductList
 */
@WebServlet("/selectproductlist")
public class SelectProductList extends HttpServlet {
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<GNAP_CATEGORY> flist =  GNAP_CATEGORYDao.selectCat("father");
		request.setAttribute("flist", flist);
		
		ArrayList<GNAP_CATEGORY> clist =  GNAP_CATEGORYDao.selectCat("child");
		request.setAttribute("clist", clist);
		
		String fid = request.getParameter("fid");
		String cid = request.getParameter("cid");
		
		int cpage=1;//当前页面
		
		int count=4;//每页显示条数
		String cp="1";
		

		
		if(cp!=null)
		{
			cpage=Integer.parseInt(cp);
		}
		int id=0;
		int x=0;//判别fid和cid
		ArrayList<GNAP_PRODUCT> list = null;
		System.out.print("fid="+fid);
		System.out.print("cid="+cid);
		System.out.print("cp="+cp);
		if(fid!=null) {
			String[] v=fid.split("\\?",-1);
			System.out.print("v.length="+v.length);
			if(v.length==1)
			{
				id=Integer.parseInt(fid);
				list = GNAP_PRODUCTDao.selectAllByFid(id,cpage,count);
				x=0;
			}else {
				fid=v[0];
				cp=v[1];
				cp=cp.split("=")[1];
				cpage=Integer.parseInt(cp);
				id=Integer.parseInt(fid);
				list = GNAP_PRODUCTDao.selectAllByFid(id,cpage,count);
				x=0;
			}
		}
		
		if(cid!=null) {
			String[] v=cid.split("\\?",-1);
			System.out.print("v.length="+v.length);
			if(v.length==1)
			{
				id=Integer.parseInt(cid);
				list = GNAP_PRODUCTDao.selectAllByCid(id,cpage,count);
				x=1;
			}else {
				cid=v[0];
				cp=v[1];
				cp=cp.split("=")[1];
				cpage=Integer.parseInt(cp);
				id=Integer.parseInt(cid);
				list = GNAP_PRODUCTDao.selectAllByCid(id,cpage,count);
				x=1;
			}
		}
		System.out.print("fid="+fid);
		System.out.print("cid="+cid);
		System.out.print("cp:"+cp);
		
		int arr[]=GNAP_PRODUCTDao.totalPage(count,x,id);
		request.setAttribute("tsum", arr[0]);
		request.setAttribute("tpage",arr[1]);
		request.setAttribute("cpage", cpage);
		request.setAttribute("title", GNAP_CATEGORYDao.selectById(id).getCATE_NAME());
		request.setAttribute("list", list);
		request.setAttribute("x", x);
		request.setAttribute("id", id);
		request.getRequestDispatcher("productlist.jsp").forward(request, response);
	}



}
